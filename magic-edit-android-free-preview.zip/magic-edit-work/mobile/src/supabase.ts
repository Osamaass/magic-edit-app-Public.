import { createClient } from "@supabase/supabase-js";
import * as SecureStore from "expo-secure-store";
import { Platform } from "react-native";

const url = process.env.EXPO_PUBLIC_SUPABASE_URL || "";
const anon = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || "";

const SecureStorage = {
  getItem: (key: string) => Platform.OS === "web" ? Promise.resolve(null) : SecureStore.getItemAsync(key),
  setItem: (key: string, value: string) => Platform.OS === "web" ? Promise.resolve() : SecureStore.setItemAsync(key, value),
  removeItem: (key: string) => Platform.OS === "web" ? Promise.resolve() : SecureStore.deleteItemAsync(key)
};

export const supabase = createClient(url, anon, {
  auth: { storage: SecureStorage, autoRefreshToken: true, persistSession: true, detectSessionInUrl: false }
});