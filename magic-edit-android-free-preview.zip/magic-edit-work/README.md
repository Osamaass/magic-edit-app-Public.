# التعديل السحري — نسخة تجريبية مجانية لـ Android

هذه حزمة مصدر التطبيق والخادم. **ليست APK جاهزاً للتثبيت**؛ لا بد من إعداد خدمات الحساب والمعالجة ثم تشغيل بناء سحابي مرة واحدة. لا تحتاج إلى كمبيوتر شخصي، ويمكن تنفيذ خطوات البناء من متصفح الهاتف عبر GitHub Codespaces وExpo EAS.

## ما تتضمنه النسخة التجريبية
- واجهة عربية RTL، اختيار صورة أو فيديو، وصف التعديل، متابعة حالة المهمة.
- تسجيل بالبريد وكلمة المرور، وزر متابعة باستخدام Google (OAuth عبر Supabase).
- خمس وحدات مجانية أولية لكل حساب، وسجل تعديلات.
- لا توجد اشتراكات أو مدفوعات في النسخة التجريبية.
- إرجاع الرصيد إذا فشل بدء المهمة بعد الخصم.

## تنبيه مهم عن مزود الذكاء الاصطناعي
يلزم اختيار نموذج Replicate متوافق مع نوع الوسائط. لا يوجد نموذج واحد مضمون لقبول الصور والفيديو معاً. أسماء حقول الإدخال `REPLICATE_MEDIA_FIELD` و`REPLICATE_PROMPT_FIELD` يجب أن تطابق مخطط النموذج المختار. قد يستهلك المزود رصيداً/تكلفة من حسابه حتى لو كان التطبيق مجانياً للمستخدم؛ راقب حدود الاستخدام ولا تنشر مفاتيح API.

## 1) إعداد Supabase
1. أنشئ مشروعاً في https://supabase.com
2. افتح SQL Editor وشغّل `supabase/schema.sql` مرة واحدة.
3. من Authentication > Providers فعّل Email وGoogle.
4. من Project Settings > API احتفظ بـ Project URL وanon key وservice_role key. لا تضع service_role في التطبيق ولا ترسله في المحادثات.
5. في Authentication > URL Configuration أضف رابط إعادة التوجيه `magicedit://auth/callback` إلى Redirect URLs. اضبط Site URL حسب نطاق الخادم عند نشره.

## 2) إعداد Google OAuth
1. افتح https://console.cloud.google.com/ وأنشئ مشروعاً.
2. جهّز OAuth consent screen، ثم أنشئ OAuth Client ID من نوع Web application.
3. في Authorized redirect URI أضف عنوان Callback الذي يعرضه Supabase في إعدادات Google Provider، ويكون عادةً `https://YOUR_PROJECT.supabase.co/auth/v1/callback`.
4. انسخ Client ID وClient Secret إلى إعدادات Google Provider في Supabase. لا تضع السر في تطبيق الهاتف.
5. في Supabase تأكد من إضافة `magicedit://auth/callback` ضمن Redirect URLs.

## 3) إعداد الخادم
انشر مجلد `backend` على استضافة تدعم Next.js وNode.js (مثل Vercel). أضف متغيرات البيئة التالية في لوحة الاستضافة:
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `REPLICATE_API_TOKEN`
- `REPLICATE_MODEL_VERSION`
- `REPLICATE_MEDIA_FIELD` (مثلاً `image` حسب النموذج)
- `REPLICATE_PROMPT_FIELD` (غالباً `prompt` حسب النموذج)
- `CREDIT_COST_PER_JOB=1`

انسخ عنوان HTTPS المنشور؛ سيستخدمه تطبيق الهاتف كـ `EXPO_PUBLIC_API_URL`.

## 4) بناء APK من الهاتف فقط
1. أنشئ حساباً في https://github.com/signup ثم مستودعاً خاصاً وارفع ملفات المشروع إليه بعد فك ZIP.
2. افتح GitHub Codespaces من المستودع عبر المتصفح، وأنشئ Codespace.
3. في الطرفية:
   ```bash
   cd mobile
   npm install
   npm install -g eas-cli
   eas login
   eas build:configure
   ```
4. أنشئ ملف `mobile/.env` من `.env.example` وضع فيه عنوان الخادم وSupabase URL وanon key (هذه القيم العامة للتطبيق فقط؛ لا تضع service_role أو Replicate token هنا).
5. نفّذ:
   ```bash
   eas build --platform android --profile preview
   ```
6. عند اكتمال البناء افتح رابط Build من Expo على هاتفك ونزّل APK وثبّته.

## 5) اختبار Google
- أضف بريدك إلى Test users في شاشة موافقة Google إذا كان التطبيق في وضع Testing.
- تأكد من أن Supabase Google Provider مفعّل.
- جرّب تسجيل الدخول، ثم ارفع صورة تجريبية تملك حق تعديلها.

## حدود النسخة التجريبية
- لا توجد مدفوعات أو اشتراكات.
- خمس وحدات مجانية لكل حساب؛ وهي ليست ضماناً لاستخدام غير محدود لأن تشغيل النموذج له تكلفة على مالك الخدمة.
- دعم الفيديو يعتمد كلياً على نموذج Replicate المختار وحقول إدخاله وحدوده.
- قبل الإطلاق العام أضف سياسة خصوصية وموافقة واضحة على إرسال الوسائط إلى Replicate، وحذف الحساب والبيانات، وحدود طلبات، وفحص ملفات أقوى، وتخزيناً خاصاً للنتائج.
