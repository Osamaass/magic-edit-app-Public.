import {NextResponse} from "next/server";
import {admin,getUser} from "../../../../lib/server";
export const runtime="nodejs";
export async function POST(request:Request){
 let chargedUser:string|undefined, chargedAmount=0, jobId:string|undefined;
 try{
  const user=await getUser(request);if(!user)return NextResponse.json({error:"سجّل الدخول أولاً."},{status:401});
  const token=process.env.REPLICATE_API_TOKEN,version=process.env.REPLICATE_MODEL_VERSION;
  if(!token||!version||version==="your_model_version_hash")return NextResponse.json({error:"إعداد نموذج الذكاء الاصطناعي غير مكتمل على الخادم."},{status:500});
  const form=await request.formData(),file=form.get("file"),prompt=String(form.get("prompt")||"").trim(),kind=String(form.get("kind")||"image");
  if(!(file instanceof File)||!prompt)return NextResponse.json({error:"الملف والوصف مطلوبان."},{status:400});
  if(prompt.length>1500)return NextResponse.json({error:"الوصف طويل جداً؛ الحد 1500 حرف."},{status:400});
  if(file.size>100*1024*1024)return NextResponse.json({error:"حجم الملف يتجاوز 100 ميغابايت."},{status:413});
  const allowed=kind==="video"?file.type.startsWith("video/"):kind==="image"?file.type.startsWith("image/"):false;
  if(!allowed)return NextResponse.json({error:"نوع الملف لا يطابق الاختيار."},{status:415});
  const cost=Math.max(1,Number(process.env.CREDIT_COST_PER_JOB||1));
  const {data:charged,error:chargeError}=await admin.rpc("spend_credits",{p_user_id:user.id,p_amount:cost});
  if(chargeError||!charged)return NextResponse.json({error:"رصيدك غير كافٍ أو تعذر تحديث الرصيد."},{status:402});
  chargedUser=user.id;chargedAmount=cost;
  const {data:job,error:jobError}=await admin.from("jobs").insert({user_id:user.id,prompt,kind,status:"starting",credits_spent:cost}).select("id").single();
  if(jobError)throw jobError;jobId=job.id;
  const uploadForm=new FormData();uploadForm.append("content",file,file.name);
  const up=await fetch("https://api.replicate.com/v1/files",{method:"POST",headers:{Authorization:`Bearer ${token}`},body:uploadForm});
  const upData=await up.json();
  if(!up.ok)throw new Error(upData.detail||"تعذر رفع الملف إلى مزود المعالجة.");
  const mediaField=process.env.REPLICATE_MEDIA_FIELD||"image",promptField=process.env.REPLICATE_PROMPT_FIELD||"prompt";
  const mediaUrl=upData.urls?.get||upData.url;if(!mediaUrl)throw new Error("لم يرجع مزود المعالجة رابط الملف.");
  const prediction=await fetch("https://api.replicate.com/v1/predictions",{method:"POST",headers:{Authorization:`Bearer ${token}`,"Content-Type":"application/json"},body:JSON.stringify({version,input:{[mediaField]:mediaUrl,[promptField]:prompt}})});
  const pd=await prediction.json();
  if(!prediction.ok)throw new Error(pd.detail||"رفض نموذج الذكاء الاصطناعي الطلب.");
  await admin.from("jobs").update({provider_id:pd.id,status:pd.status}).eq("id",job.id);
  return NextResponse.json({id:job.id,status:pd.status});
 }catch(e:any){
  console.error(e);
  if(jobId){await admin.from("jobs").update({status:"failed",error:e.message||"تعذر بدء المهمة."}).eq("id",jobId);await admin.rpc("refund_job_once",{p_job_id:jobId});}
  else if(chargedUser&&chargedAmount){await admin.rpc("refund_credits",{p_user_id:chargedUser,p_amount:chargedAmount});}
  return NextResponse.json({error:e.message||"حدث خطأ بالخادم."},{status:500});
 }
}
