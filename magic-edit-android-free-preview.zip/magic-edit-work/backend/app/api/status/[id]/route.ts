import {NextResponse} from "next/server";
import {admin,getUser} from "../../../../lib/server";
export const runtime="nodejs";
export async function GET(request:Request,context:{params:{id:string}}){
 const user=await getUser(request);if(!user)return NextResponse.json({error:"سجّل الدخول أولاً."},{status:401});
 const {data:job,error}=await admin.from("jobs").select("*").eq("id",context.params.id).eq("user_id",user.id).single();
 if(error||!job)return NextResponse.json({error:"المهمة غير موجودة."},{status:404});
 if(!job.provider_id)return NextResponse.json({id:job.id,status:job.status,error:job.error});
 const token=process.env.REPLICATE_API_TOKEN!;
 const r=await fetch(`https://api.replicate.com/v1/predictions/${encodeURIComponent(job.provider_id)}`,{headers:{Authorization:`Bearer ${token}`},cache:"no-store"});
 const d=await r.json();
 if(!r.ok)return NextResponse.json({error:d.detail||"تعذرت قراءة حالة المهمة."},{status:r.status});
 await admin.from("jobs").update({status:d.status,output:d.output,error:d.error}).eq("id",job.id);
 if(d.status==="failed"||d.status==="canceled"){
   await admin.rpc("refund_job_once",{p_job_id:job.id});
 }
 return NextResponse.json({id:job.id,status:d.status,output:d.output,error:d.error});
}