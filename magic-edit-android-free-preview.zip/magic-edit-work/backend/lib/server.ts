import { createClient } from "@supabase/supabase-js";
export const admin = createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {auth:{persistSession:false}});
export async function getUser(request: Request) {
  const header=request.headers.get("authorization")||"";
  const token=header.startsWith("Bearer ")?header.slice(7):"";
  if(!token) return null;
  const {data,error}=await admin.auth.getUser(token);
  return error?null:data.user;
}