-- Run in Supabase SQL Editor. Enable email auth in Supabase Auth settings.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  credits integer not null default 5 check (credits >= 0),
  plan text not null default 'free',
  created_at timestamptz not null default now()
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider_id text,
  prompt text not null,
  kind text not null check (kind in ('image','video')),
  status text not null default 'starting',
  output jsonb,
  error text,
  credits_spent integer not null default 1,
  refunded_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.jobs enable row level security;

drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles for select using (auth.uid() = id);
drop policy if exists "read own jobs" on public.jobs;
create policy "read own jobs" on public.jobs for select using (auth.uid() = user_id);

create or replace function public.create_profile_for_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,credits,plan) values(new.id,5,'free')
  on conflict(id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created_magic on auth.users;
create trigger on_auth_user_created_magic after insert on auth.users
for each row execute procedure public.create_profile_for_new_user();

create or replace function public.spend_credits(p_user_id uuid,p_amount integer)
returns boolean language plpgsql security definer set search_path=public as $$
declare changed integer;
begin
  if p_amount < 1 then return false; end if;
  update public.profiles set credits=credits-p_amount
  where id=p_user_id and credits>=p_amount;
  get diagnostics changed = row_count;
  return changed=1;
end; $$;

create or replace function public.refund_credits(p_user_id uuid,p_amount integer)
returns void language sql security definer set search_path=public as $$
  update public.profiles set credits=credits+p_amount where id=p_user_id;
$$;

create or replace function public.refund_job_once(p_job_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare uid uuid; amount integer;
begin
  update public.jobs set refunded_at=now()
  where id=p_job_id and refunded_at is null
  returning user_id,credits_spent into uid,amount;
  if uid is not null then
    update public.profiles set credits=credits+amount where id=uid;
  end if;
end; $$;

-- Restrict RPC execution. The backend service role invokes these functions.
revoke all on function public.spend_credits(uuid,integer) from public, anon, authenticated;
revoke all on function public.refund_credits(uuid,integer) from public, anon, authenticated;
revoke all on function public.refund_job_once(uuid) from public, anon, authenticated;
grant execute on function public.spend_credits(uuid,integer) to service_role;
grant execute on function public.refund_credits(uuid,integer) to service_role;
grant execute on function public.refund_job_once(uuid) to service_role;

grant select on public.profiles to authenticated;
grant select on public.jobs to authenticated;
